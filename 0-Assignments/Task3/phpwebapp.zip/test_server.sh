#!/bin/bash
# Quick test server script for local development

echo "Starting PHP development server..."
echo "Access the application at: http://localhost:8000"
echo "Press Ctrl+C to stop the server"
echo ""

cd "$(dirname "$0")"
php -S localhost:8000
