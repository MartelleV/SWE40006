# Translation Notes: ASP.NET Core MVC to PHP

## Architecture Mapping

### ASP.NET Core → PHP Equivalent

| ASP.NET Core | PHP Translation |
|--------------|-----------------|
| Program.cs | index.php (routing) |
| Controllers | controllers/ directory |
| Models | Arrays/Associative arrays |
| Views (Razor) | PHP templates |
| ViewData | PHP variables |
| Dependency Injection | Direct includes |
| Routing | Query string parameters |
| Tag Helpers | Plain HTML |
| Model Binding | $_GET/$_POST |

## Key Differences

### 1. Routing

**ASP.NET Core:**
```csharp
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
```

**PHP:**
```php
$page = $_GET['page'] ?? 'home';
$action = $_GET['action'] ?? 'index';
```

### 2. Controllers

**ASP.NET Core:**
```csharp
public class HomeController : Controller
{
    public IActionResult Index()
    {
        ViewData["StudentName"] = "Vu Phan Hoang An";
        return View();
    }
}
```

**PHP:**
```php
// In index.php
$studentName = "Vu Phan Hoang An";
include 'views/home/index.php';
```

### 3. Views

**Razor (ASP.NET):**
```razor
@{
    ViewData["Title"] = "Home";
}
<h1>@ViewData["StudentName"]</h1>
@foreach (var skill in skills)
{
    <span>@skill</span>
}
```

**PHP:**
```php
<?php $pageTitle = "Home"; ?>
<h1><?php echo htmlspecialchars($studentName); ?></h1>
<?php foreach ($skills as $skill): ?>
    <span><?php echo htmlspecialchars($skill); ?></span>
<?php endforeach; ?>
```

### 4. Models

**ASP.NET Core:**
```csharp
public class MusicViewModel
{
    public List<string> Genres { get; set; } = new();
    public List<ArtistItem> Artists { get; set; } = new();
}

public class ArtistItem
{
    public string Name { get; set; } = string.Empty;
    public string Genre { get; set; } = string.Empty;
}
```

**PHP:**
```php
$genres = ["Rock", "Blues", "Jazz"];
$artists = [
    ["name" => "Led Zeppelin", "genre" => "Rock"],
    ["name" => "Daft Punk", "genre" => "Dance"]
];
```

### 5. Static Methods

**ASP.NET Core:**
```csharp
public static class ImageConfig
{
    public static string GetArtistImage(string artistName)
    {
        var fileName = SanitizeFileName(artistName);
        return $"{BasePath}/artists/{fileName}.webp";
    }
}
```

**PHP:**
```php
function getArtistImage($artistName) {
    $fileName = sanitizeFileName($artistName);
    return "assets/images/music/artists/{$fileName}.webp";
}
```

### 6. Layout/Master Pages

**Razor:**
```razor
<!DOCTYPE html>
<html>
<head>
    <title>@ViewData["Title"]</title>
</head>
<body>
    @RenderBody()
</body>
</html>
```

**PHP:**
```php
// header.php
<!DOCTYPE html>
<html>
<head>
    <title><?php echo $pageTitle; ?></title>
</head>
<body>

// footer.php
</body>
</html>

// In view:
<?php include 'views/shared/header.php'; ?>
<!-- Content here -->
<?php include 'views/shared/footer.php'; ?>
```

## Security Considerations

### XSS Prevention

**ASP.NET Core:**
- Automatic HTML encoding in Razor
- `@Html.Raw()` for unencoded output

**PHP:**
- Manual encoding with `htmlspecialchars()`
- Always escape user input

### CSRF Protection

**ASP.NET Core:**
- Built-in anti-forgery tokens
- `@Html.AntiForgeryToken()`

**PHP:**
- Manual implementation needed
- Use session tokens for forms

### SQL Injection

**ASP.NET Core:**
- Entity Framework with parameterized queries
- LINQ to SQL

**PHP:**
- PDO with prepared statements
- Never concatenate SQL strings

## Features Not Translated

1. **Dependency Injection** - PHP uses direct includes
2. **Middleware Pipeline** - Not implemented
3. **Model Validation** - Would need manual implementation
4. **Tag Helpers** - Plain HTML used instead
5. **Bundling/Minification** - Would need separate tools
6. **Configuration System** - Simple constants used
7. **Logging Framework** - Basic error_log() used
8. **Authentication/Authorization** - Not implemented

## Advantages of PHP Version

1. **Simplicity** - No build process required
2. **Portability** - Runs on any PHP-enabled server
3. **Debugging** - Direct file editing and testing
4. **Hosting** - Cheaper and more widely available
5. **Learning Curve** - Easier for beginners

## Disadvantages of PHP Version

1. **Type Safety** - No compile-time type checking
2. **Performance** - Generally slower than compiled C#
3. **Architecture** - Less structured than MVC framework
4. **Tooling** - Fewer IDE features compared to Visual Studio
5. **Scalability** - Manual implementation of enterprise features

## Testing the Translation

### Functional Equivalence Checklist

- [x] Home page displays student information
- [x] Skills are listed correctly
- [x] Music page shows all tabs (Genres, Artists, Songs, Albums)
- [x] Genre cards display with correct colors and emojis
- [x] Artist images load with fallback to initials
- [x] Songs display with play icons
- [x] Albums display with cover images
- [x] Navigation works between pages
- [x] Error page displays for invalid routes
- [x] All CSS styling preserved
- [x] All JavaScript functionality preserved
- [x] Responsive design works on mobile

## Maintenance Notes

### Adding New Pages

1. Create view file in `views/` directory
2. Add controller logic if needed in `controllers/`
3. Update routing in `index.php`
4. Add page/action to `ALLOWED_PAGES`/`ALLOWED_ACTIONS` in config.php

### Adding Database Support

1. Copy `database/db_config.example.php` to `database/db_config.php`
2. Run `database/schema.sql` to create tables
3. Update index.php to use `music_controller_db.php`
4. Implement other database-backed features as needed

### Performance Tuning

1. Enable OPcache in production
2. Use database instead of in-memory arrays for large datasets
3. Implement caching for frequently accessed data
4. Consider using a PHP framework (Laravel, Symfony) for larger applications
