# Quick Start Guide

## Running Locally

### Option 1: PHP Built-in Server (Easiest)

```bash
cd PHPApp
php -S localhost:8000
```

Then open your browser to: `http://localhost:8000`

### Option 2: XAMPP/WAMP/MAMP

1. Install XAMPP, WAMP, or MAMP
2. Copy PHPApp folder to htdocs (XAMPP) or www (WAMP/MAMP)
3. Start Apache
4. Open: `http://localhost/PHPApp`

### Option 3: Docker

```bash
cd PHPApp
docker run -d -p 8080:80 -v $(pwd):/var/www/html php:8.1-apache
```

Open: `http://localhost:8080`

## URLs

- **Home Page**: `index.php` or `index.php?page=home&action=index`
- **Music Page**: `index.php?page=home&action=music`

## File Structure

```
PHPApp/
├── index.php              # Main entry point
├── config.php             # Configuration
├── .htaccess              # Apache configuration
├── controllers/           # Data controllers
│   ├── music_controller.php
│   └── music_controller_db.php
├── views/                 # HTML templates
│   ├── home/
│   │   ├── index.php
│   │   └── music.php
│   └── shared/
│       ├── header.php
│       ├── footer.php
│       └── error.php
├── helpers/               # Helper functions
│   └── image_helper.php
├── database/              # Database files (optional)
│   ├── schema.sql
│   └── db_config.example.php
└── assets/                # Static files
    ├── css/
    ├── js/
    ├── images/
    └── lib/
```

## Making Changes

### Add a New Page

1. Create view file: `views/home/newpage.php`
2. Add route in `index.php`:
```php
elseif ($page === 'home' && $action === 'newpage') {
    $pageTitle = "New Page";
    include 'views/home/newpage.php';
}
```
3. Add to allowed actions in `config.php`:
```php
define('ALLOWED_ACTIONS', ['index', 'music', 'newpage']);
```

### Modify Student Information

Edit `config.php`:
```php
define('STUDENT_NAME', 'Your Name');
define('STUDENT_ID', 'Your ID');
```

### Add Music Data

Edit `controllers/music_controller.php`:
```php
$artists[] = ["name" => "New Artist", "genre" => "Rock"];
$songs[] = ["title" => "New Song", "artist" => "Artist Name"];
```

## Troubleshooting

**Problem**: CSS not loading
- **Solution**: Check that assets folder exists and has correct permissions

**Problem**: Page not found
- **Solution**: Verify page and action are in ALLOWED_PAGES and ALLOWED_ACTIONS

**Problem**: PHP errors displayed
- **Solution**: Check PHP version is 8.0+, review error messages

## Next Steps

- Read `TRANSLATION_NOTES.md` for architecture details
- Read `DEPLOYMENT.md` for production deployment
- Set up database (optional) using `database/schema.sql`
