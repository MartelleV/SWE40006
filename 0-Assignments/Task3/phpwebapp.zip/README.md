# StudentPortfolio - PHP Version

This is a PHP translation of the ASP.NET Core MVC StudentPortfolio application.

## Structure

```
PHPApp/
├── index.php                 # Main entry point with routing
├── .htaccess                 # Apache configuration
├── controllers/              # Data controllers
│   └── music_controller.php  # Music data
├── views/                    # View templates
│   ├── home/
│   │   ├── index.php         # Home page
│   │   └── music.php         # Music page
│   └── shared/
│       ├── header.php        # Header template
│       ├── footer.php        # Footer template
│       └── error.php         # Error page
├── helpers/                  # Helper functions
│   └── image_helper.php      # Image path utilities
└── assets/                   # Static files (CSS, JS, images)
    ├── css/
    ├── js/
    ├── images/
    └── lib/
```

## Requirements

- PHP 8.0 or higher
- Apache web server with mod_rewrite enabled
- No database required (all data is in-memory)

## Installation

1. Copy the PHPApp directory to your web server's document root
2. Ensure Apache mod_rewrite is enabled
3. Access the application via your web browser

## URLs

- Home: `index.php?page=home&action=index` or just `index.php`
- Music: `index.php?page=home&action=music`

With mod_rewrite enabled, you can also use clean URLs.

## Features

- Simple routing system
- MVC-like structure with controllers and views
- Reusable header/footer templates
- Image helper functions
- All original styling and JavaScript preserved
- XSS protection with htmlspecialchars()

## Differences from ASP.NET Version

- No dependency injection container
- Simple array-based data instead of models
- Basic routing instead of ASP.NET Core routing
- No Razor syntax (pure PHP)
- Static data instead of potential database integration
