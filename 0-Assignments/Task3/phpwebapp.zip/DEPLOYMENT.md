# Deployment Guide - PHP Version

## Prerequisites

- PHP 8.0 or higher
- Apache 2.4+ with mod_rewrite enabled
- (Optional) MySQL 5.7+ or MariaDB 10.3+ for database storage

## Deployment Steps

### 1. Prepare the Server

```bash
# Install PHP and Apache (Ubuntu/Debian)
sudo apt update
sudo apt install php8.1 apache2 libapache2-mod-php8.1

# Enable mod_rewrite
sudo a2enmod rewrite

# Restart Apache
sudo systemctl restart apache2
```

### 2. Upload Files

Upload the entire PHPApp directory to your web server:

```bash
# Using SCP
scp -r PHPApp/ user@server:/var/www/html/

# Or using FTP/SFTP client
```

### 3. Set Permissions

```bash
cd /var/www/html/PHPApp
chmod 755 .
chmod 644 *.php
chmod 644 .htaccess
```

### 4. Configure Apache

Edit your Apache virtual host configuration:

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    DocumentRoot /var/www/html/PHPApp
    
    <Directory /var/www/html/PHPApp>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/portfolio_error.log
    CustomLog ${APACHE_LOG_DIR}/portfolio_access.log combined
</VirtualHost>
```

Restart Apache:
```bash
sudo systemctl restart apache2
```

### 5. (Optional) Database Setup

If you want to use MySQL instead of in-memory data:

```bash
# Create database
mysql -u root -p < database/schema.sql

# Configure database connection
cp database/db_config.example.php database/db_config.php
nano database/db_config.php  # Edit with your credentials

# Update index.php to use database controller
# Change: include 'controllers/music_controller.php';
# To: include 'controllers/music_controller_db.php';
```

### 6. Security Hardening

```bash
# Disable directory listing (already in .htaccess)
# Set proper file permissions
find . -type f -exec chmod 644 {} \;
find . -type d -exec chmod 755 {} \;

# Protect sensitive files
echo "deny from all" > database/.htaccess
```

### 7. Production Configuration

Edit `config.php` for production:

```php
// Disable error display
error_reporting(0);
ini_set('display_errors', 0);

// Enable error logging
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/php/portfolio_errors.log');
```

## Deployment Checklist

- [ ] PHP 8.0+ installed
- [ ] Apache mod_rewrite enabled
- [ ] Files uploaded to server
- [ ] Permissions set correctly
- [ ] Apache virtual host configured
- [ ] .htaccess working (test with clean URLs)
- [ ] Static assets loading (CSS, JS, images)
- [ ] Error reporting disabled in production
- [ ] (Optional) Database configured and populated
- [ ] SSL certificate installed (recommended)

## Testing

1. Access home page: `http://yourdomain.com/`
2. Navigate to music page: `http://yourdomain.com/index.php?page=home&action=music`
3. Test clean URLs (if mod_rewrite is working)
4. Check browser console for JavaScript errors
5. Verify all images load correctly

## Troubleshooting

### .htaccess not working
```bash
# Check if mod_rewrite is enabled
apache2ctl -M | grep rewrite

# Check AllowOverride in Apache config
# Should be "AllowOverride All" not "AllowOverride None"
```

### CSS/JS not loading
- Check file paths in header.php
- Verify assets directory permissions
- Check Apache error logs

### Database connection errors
- Verify credentials in db_config.php
- Check MySQL service is running
- Ensure database user has proper permissions

## Performance Optimization

1. Enable OPcache in php.ini:
```ini
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=10000
```

2. Enable compression (already in .htaccess)

3. Set up CDN for static assets (optional)

4. Use PHP-FPM instead of mod_php for better performance
